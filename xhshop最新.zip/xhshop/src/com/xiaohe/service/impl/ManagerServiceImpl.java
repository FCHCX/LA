package com.xiaohe.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.xiaohe.mapper.ControllersMapper;
import com.xiaohe.mapper.ControllersMapperCustom;
import com.xiaohe.mapper.PowerMapper;
import com.xiaohe.po.Controllers;
import com.xiaohe.po.ControllersCustom;
import com.xiaohe.po.ControllersQueryVo;
import com.xiaohe.po.PowerCustom;
import com.xiaohe.po.PowerQueryVo;
import com.xiaohe.service.ManagerService;

public class ManagerServiceImpl implements ManagerService{
	
	@Autowired
	private ControllersMapper controllersMapper;
	
	@Autowired
	private ControllersMapperCustom controllersMapperCustom;
	
	@Autowired
	private PowerMapper powerMapper;
	
	
	@Override
	public void addManager(ControllersCustom controllersCustom) {
		// TODO Auto-generated method stub
		controllersMapperCustom.addManager(controllersCustom);
	}


	@Override
	public List<ControllersCustom> queryManager(ControllersCustom controllersCustom) {
		// TODO Auto-generated method stub
		return controllersMapperCustom.queryManager(controllersCustom);
		
	}


	@Override
	public void deleteManager(Integer mid) {
		// TODO Auto-generated method stub
		
		controllersMapper.deleteByPrimaryKey(mid);
		
	}


	@Override
	public void deleteMoreManager(Integer[] mid) {
		// TODO Auto-generated method stub
		ControllersQueryVo controllersQueryVo = new ControllersQueryVo();
		List<Integer> ids=new ArrayList<Integer>();
		
		for (int i=0;i<mid.length;i++) {
			ids.add(mid[i]);
		}
		
		controllersQueryVo.setManagerId(ids);
		controllersMapperCustom.deleteMoreManager(controllersQueryVo);
		
	}


	@Override
	public int queryManagerCount() {
		// TODO Auto-generated method stub
		return 	controllersMapperCustom.queryManagerCount();
		
	}


	@Override
	public ControllersCustom queryEditManager(Integer cid) {
		// TODO Auto-generated method stub
		Controllers controllers = controllersMapper.selectByPrimaryKey(cid);
		ControllersCustom controllersCustom=null;
		if(controllers!=null){
			controllersCustom = new ControllersCustom();
			BeanUtils.copyProperties(controllers, controllersCustom);
		}
		
		
		return controllersCustom ;
		
	}


	@Override
	public void managerSubmit(ControllersCustom controllersCustom) {
		// TODO Auto-generated method stub
		controllersMapper.updateByPrimaryKey(controllersCustom);
		
	}


	@Override
	public List<ControllersCustom> queryAllManager() {
		// TODO Auto-generated method stub
		
		return 	controllersMapperCustom.queryAllManager();
		
	}


	@Override
	public void addPower(PowerQueryVo powerQueryVo) {
		// TODO Auto-generated method stub
		
		//循环插入权限表，一个id对应多个菜单名与权限名称
		List<Integer> ids=powerQueryVo.getIds();
		List<String> menuMame=powerQueryVo.getMenuName();
		for(int i=0;i<ids.size();i++){
			powerQueryVo.setIntegerId(ids.get(i));
			for(int j=0;j<menuMame.size();j++){
				powerQueryVo.setsMunuName(menuMame.get(j));
				controllersMapperCustom.addPower(powerQueryVo);
				
			}
			
		}
		
	}


	@Override
	public List<ControllersCustom> queryAllManagerByGroup() {
		// TODO Auto-generated method stub
		return controllersMapperCustom.queryAllManagerByGroup();
		
	}


	@Override
	public ControllersCustom findManagerById(Integer cid) {
		// TODO Auto-generated method stub
		Controllers controllers = controllersMapper.selectByPrimaryKey(cid);
		ControllersCustom controllersCustom = null;
		if(controllers!=null){
			controllersCustom=new ControllersCustom();
			BeanUtils.copyProperties(controllers, controllersCustom);
		}
		
		return controllersCustom;
	}


	@Override
	public List<PowerCustom> findManagerPowerById(Integer cid) {
		// TODO Auto-generated method stub
		
		return controllersMapperCustom.findManagerPowerById(cid);
		
	}


	@Override
	public void deletePower(Integer cid) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public int selectPowerCount(Integer cid) {
		// TODO Auto-generated method stub
		return controllersMapperCustom.selectPowerCount(cid);
	}


	@Override
	public void updatePower(PowerQueryVo powerQueryVo,int count,int cid) {
		// TODO Auto-generated method stub
		if(count>0){
		for(int i=0;i<count;i++){
			controllersMapperCustom.deleteMorePower(cid);
			
		}
		}
		
		
		List<String> menuMame=powerQueryVo.getMenuName();
		//单个用户循环插入多个权限
		
		powerQueryVo.setIntegerId(cid);
		for(int j=0;j<menuMame.size();j++){
			powerQueryVo.setsMunuName(menuMame.get(j));
			controllersMapperCustom.addPowerBySingle(powerQueryVo);
			
		}
		
		
		//循环插入权限表，一个id对应多个菜单名与权限名称
				/*List<Integer> ids=powerQueryVo.getIds();
				List<String> menuMame=powerQueryVo.getMenuName();
				for(int i=0;i<ids.size();i++){
					powerQueryVo.setIntegerId(ids.get(i));
					for(int j=0;j<menuMame.size();j++){
						powerQueryVo.setsMunuName(menuMame.get(j));
						controllersMapperCustom.addPower(powerQueryVo);
						
					}
					
				}*/
		
		
		
	}

}
