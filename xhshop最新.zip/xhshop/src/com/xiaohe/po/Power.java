package com.xiaohe.po;

public class Power {
    private Integer pid;

    private Integer pcid;

    private String pwname;

    private String pdetail;

    private String pmenu;

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Integer getPcid() {
        return pcid;
    }

    public void setPcid(Integer pcid) {
        this.pcid = pcid;
    }

    public String getPwname() {
        return pwname;
    }

    public void setPwname(String pwname) {
        this.pwname = pwname == null ? null : pwname.trim();
    }

    public String getPdetail() {
        return pdetail;
    }

    public void setPdetail(String pdetail) {
        this.pdetail = pdetail == null ? null : pdetail.trim();
    }

    public String getPmenu() {
        return pmenu;
    }

    public void setPmenu(String pmenu) {
        this.pmenu = pmenu == null ? null : pmenu.trim();
    }
}