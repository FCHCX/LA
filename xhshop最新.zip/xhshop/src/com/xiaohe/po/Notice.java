package com.xiaohe.po;

import java.util.Date;

public class Notice {
    private Integer ntid;

    private String ntcontent;

    private Date ntime;

    private String ntitle;

    public Integer getNtid() {
        return ntid;
    }

    public void setNtid(Integer ntid) {
        this.ntid = ntid;
    }

    public String getNtcontent() {
        return ntcontent;
    }

    public void setNtcontent(String ntcontent) {
        this.ntcontent = ntcontent == null ? null : ntcontent.trim();
    }

    public Date getNtime() {
        return ntime;
    }

    public void setNtime(Date ntime) {
        this.ntime = ntime;
    }

    public String getNtitle() {
        return ntitle;
    }

    public void setNtitle(String ntitle) {
        this.ntitle = ntitle == null ? null : ntitle.trim();
    }
}