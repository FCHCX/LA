package com.xiaohe.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.xiaohe.po.PointCustom;
import com.xiaohe.po.ShopinfoCustom;
import com.xiaohe.po.UserinfoCustom;
import com.xiaohe.po.UsersCustom;
import com.xiaohe.po.UsersQueryVo;
import com.xiaohe.service.MemberService;


@Controller
@RequestMapping("/member")
public class MemberController {
	@Autowired
	private MemberService memberService;
	
	//添加会员
	@RequestMapping("/addMember")
	
	public String addMember(UsersQueryVo usersQueryVo,Model model,HttpServletRequest request){
		int count=memberService.queryMember(usersQueryVo);
		String message="用户名已存在";
		
//			String message="用户名已存在";
			//model.addAttribute(message);
			if(count>=1){
				model.addAttribute("message", message);
//				HttpSession session =request.getSession();
//				session.setAttribute("message", message);
				return "redirect:/member/searchUsers.action";
			
			}
//			System.out.println("sfa");
			//return "user_list";
		
		
		memberService.addMember(usersQueryVo);
		//memberService.addMemberInfo(usersQueryVo);
		return "redirect:/member/searchUsers.action";
		
		
		
	}
	
	//单个删除会员
	@RequestMapping("/deleteMember")
	public String deleteMember(String member){
		
		memberService.deleteMember(member);
		
		return "redirect:/member/searchUsers.action";
		
		
		
	}
	
	//批量删除会员
	@RequestMapping("/deleteMoreMember")
	public String deleteMoreMember(String [] member){
		memberService.deleteMoreMember(member);
		return "redirect:/member/searchUsers.action";
		
		
		
	}
	
	//查询用户，默认查询所有用户
	@RequestMapping("/searchUsers")
	public String searchUsers(UsersQueryVo usersQueryVo,Model model){
		int count=memberService.selectUsersCount();
		model.addAttribute("count", count);
		List<UserinfoCustom> usersList=memberService.searchUsers(usersQueryVo);
		model.addAttribute("usersList", usersList);
		return "user_list";
		
	}
	
	//查询用户  跳转修改页面
		@RequestMapping(value="/editUsers",method={RequestMethod.GET,RequestMethod.POST})
		public String editItems(Model model, String member) throws Exception{
//			ModelAndView modelAndView = new ModelAndView();
			//ShopinfoCustom shopinfoCustom=itemsService.findItemsById(items_id);
			//查询用户,按名称查询
			//UserinfoCustom userinfoCustom=memberService.findUsers(member);
			UsersQueryVo usersQueryVo=memberService.findUsers(member);
			//判断商品是否为空，抛出异常提示用户
//			if(itemsCustom==null){
//				throw new CustomException("您查询的商品信息不存在");
//			}
			model.addAttribute("users", usersQueryVo);
			/*modelAndView.addObject("itemsCustom", itemsCustom);
			modelAndView.setViewName("items/editItems");*/
			return "users-update";
		}
	
	
	//修改会员信息并提交
	@RequestMapping("/updateUsers")
	public String updateUsers(UsersQueryVo usersQueryVo){
		memberService.updateUsers(usersQueryVo);
		return "redirect:/member/searchUsers.action";
		
	}
	
	
	
	//根据用户名查询，在积分表中
	@RequestMapping("/searchUsersInPoint")
	public String searchUsersInPoint(PointCustom pointCustom,Model model){
		
		//查询积分表记录条数
		int count = memberService.queryPointCount();
		model.addAttribute("count", count);
		List<PointCustom> usersList = memberService.searchUsersInPoint(pointCustom);
		model.addAttribute("usersList", usersList);
		
		return "user_point";
		
		
		
		
	}
	
	
	//积分表中单个删除
	@RequestMapping("/deletePointById")
	public String deletePointById(int point_id){
		memberService.deletePointById(point_id);
		
		return "redirect:/member/searchUsersInPoint.action";
		
		
		
	}
	
	
	//积分表批量删除
	@RequestMapping("/deletePointByMoreId")
	public String deletePointByMoreId(Integer [] point_id){
		
		memberService.deletePointByMoreId(point_id);
		return "user_point";
		
		
		
	}
	

}
