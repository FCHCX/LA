package com.xiaohe.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xiaohe.po.Store;
import com.xiaohe.po.StoreShopInfoVo;
import com.xiaohe.service.StoreService;



@Controller
@RequestMapping("/store")
public class StoreController {
	
	@Autowired
	private StoreService storeService;
	
	//添加仓库
	@RequestMapping("/addstore")
	public String addStore(Store store)throws Exception{
		storeService.addStore(store);
		return "redirect:/store/searchstore.action";
	}
	
	//查询仓库
	@RequestMapping("/searchstore")
	public String searchStore(Model model)throws Exception{
		List<StoreShopInfoVo> storelist = storeService.searchStore();
		model.addAttribute("storelist", storelist);
		int number = storeService.qureyCountStore();
		model.addAttribute("number", number);
		return "Shop_list";
	}
	
	//按条件查询
	@RequestMapping("/findstore")
	public String findstore (Model model,StoreShopInfoVo storeShopInfoVo)throws Exception{
		List<StoreShopInfoVo> storelist = storeService.findstore(storeShopInfoVo);
		model.addAttribute("storelist", storelist);
		int number = storeService.QueryFindNumber(storeShopInfoVo);
		model.addAttribute("number", number);
		return "Shop_list";
	}
	
	//修改仓库
	@RequestMapping("/updatestore")
	public String updatestore(Store store)throws Exception{
	
		storeService.UpdateStore(store);
		return "redirect:/store/searchstore.action";
	}
	
	
	//删除单个
	@RequestMapping("/deletestore")
	public String deletestore(Integer stid)throws Exception{
		storeService.DeleteStoreById(stid);
		return "redirect:/store/searchstore.action";
		
	}
	//批量删除仓库
	@RequestMapping("/DeleteStoreByMoreId")
	public String deleteStoreByMoreId(Integer [] stid) throws Exception{
		if(stid != null){
			storeService.deleteStoreByMoreId(stid);
			return "redirect:/store/searchstore.action";
		}
		return "redirect:/store/searchstore.action";
				
	}
}
