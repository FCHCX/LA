package com.xiaohe.po;

public class UsersCustom  extends Users{

}
