package com.xiaohe.po;

public class UserinfoCustom extends Userinfo{

}
