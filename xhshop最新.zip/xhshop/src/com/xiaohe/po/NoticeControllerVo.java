package com.xiaohe.po;

public class NoticeControllerVo {

	private Notice notice ;
	
	private Controllers controllers;

	public Notice getNotice() {
		return notice;
	}

	public void setNotice(Notice notice) {
		this.notice = notice;
	}

	public Controllers getControllers() {
		return controllers;
	}

	public void setControllers(Controllers controllers) {
		this.controllers = controllers;
	}
	
	
	
}
