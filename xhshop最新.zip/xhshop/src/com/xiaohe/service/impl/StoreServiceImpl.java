package com.xiaohe.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.xiaohe.mapper.StoreMapperCustom;
import com.xiaohe.po.NoticeQueryVo;
import com.xiaohe.po.Store;
import com.xiaohe.po.StoreQueryVo;
import com.xiaohe.po.StoreShopInfoVo;
import com.xiaohe.service.StoreService;

public class StoreServiceImpl implements StoreService{
	@Autowired
	private StoreMapperCustom storeMapperCustom;
	//添加仓库
	@Override
	public void addStore(Store store) throws Exception {
		// TODO Auto-generated method stub
		storeMapperCustom.addStore(store);
	}
	//搜索仓库
	@Override
	public List<StoreShopInfoVo> searchStore() throws Exception {
		// TODO Auto-generated method stub
		return storeMapperCustom.searchStore();
	}
	//仓库总数
	@Override
	public int qureyCountStore() throws Exception {
		// TODO Auto-generated method stub
		return storeMapperCustom.qureyCountStore();
	}
	@Override
	public void DeleteStoreById(Integer store_id) throws Exception {
		// TODO Auto-generated method stub
		storeMapperCustom.DeleteStoreById(store_id);
	}
	@Override
	public void deleteStoreByMoreId(Integer[] stid) throws Exception {
		// TODO Auto-generated method stub
		StoreQueryVo storeQueryVo=new StoreQueryVo();
		List<Integer> ids= new ArrayList<Integer>();
		for (int i=0;i<stid.length;i++) {
			ids.add(stid[i]);
		}
		storeQueryVo.setIds(ids);
		storeMapperCustom.deleteStoreByMoreId(storeQueryVo);
	}
	//条件查找
	@Override
	public List<StoreShopInfoVo> findstore(StoreShopInfoVo storeShopInfoVo)
			throws Exception {
		// TODO Auto-generated method stub
		return storeMapperCustom.findstore(storeShopInfoVo);
		
	}
	//条件查找的个数
	@Override
	public int QueryFindNumber(StoreShopInfoVo storeShopInfoVo) throws Exception {
		// TODO Auto-generated method stub
		return storeMapperCustom.QueryFindNumber(storeShopInfoVo);
	}
	//修改仓库
	@Override
	public void UpdateStore(Store store) throws Exception {
		// TODO Auto-generated method stub
		storeMapperCustom.UpdateStore(store);
	}

}
