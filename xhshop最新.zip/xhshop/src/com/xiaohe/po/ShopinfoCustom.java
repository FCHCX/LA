package com.xiaohe.po;

import java.util.List;

public class ShopinfoCustom extends Shopinfo{
	
}
