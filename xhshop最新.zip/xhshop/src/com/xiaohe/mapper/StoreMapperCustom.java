package com.xiaohe.mapper;

import java.util.List;

import com.xiaohe.po.Store;
import com.xiaohe.po.StoreQueryVo;
import com.xiaohe.po.StoreShopInfoVo;

public interface StoreMapperCustom {
	//添加
	public void addStore(Store store)throws Exception;
	//计数
	public int qureyCountStore()throws Exception;
	//搜索
	public List<StoreShopInfoVo> searchStore()throws Exception;
	
	public void DeleteStoreById(Integer store_id)throws Exception;
	//批量
	public void deleteStoreByMoreId(StoreQueryVo storeQueryVo)throws Exception;
	//条件查找
	public List<StoreShopInfoVo> findstore(StoreShopInfoVo storeShopInfoVo)throws Exception;
	//条件查找到的的个数
	public int QueryFindNumber(StoreShopInfoVo storeShopInfoVo)throws Exception;
	//修改仓库
	public void UpdateStore(Store store)throws Exception;

}
