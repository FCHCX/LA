package com.xiaohe.service;

import java.util.List;

import com.xiaohe.po.ControllersCustom;
import com.xiaohe.po.PowerCustom;
import com.xiaohe.po.PowerQueryVo;

public interface ManagerService {

	public void addManager(ControllersCustom controllersCustom);

	public List<ControllersCustom> queryManager(ControllersCustom controllersCustom);

	public void deleteManager(Integer mid);

	public void deleteMoreManager(Integer[] mid);

	public int queryManagerCount();

	public ControllersCustom queryEditManager(Integer cid);

	public void managerSubmit(ControllersCustom controllersCustom);

	public List<ControllersCustom> queryAllManager();

	public void addPower(PowerQueryVo powerQueryVo);

	public List<ControllersCustom> queryAllManagerByGroup();

	
	//根据ID查询所有管理员用户
	public ControllersCustom findManagerById(Integer cid);

	public List<PowerCustom> findManagerPowerById(Integer cid);

	public void deletePower(Integer cid);

	public int selectPowerCount(Integer cid);

	public void updatePower(PowerQueryVo powerQueryVo,int count,int cid);

}
