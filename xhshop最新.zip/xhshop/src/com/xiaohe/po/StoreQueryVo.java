package com.xiaohe.po;

import java.util.List;

public class StoreQueryVo {
	
	private Store store;
	
	private List<Integer> ids;

	public Store getStore() {
		return store;
	}

	public void setStore(Store store) {
		this.store = store;
	}

	public List<Integer> getIds() {
		return ids;
	}

	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}
	
	

}
