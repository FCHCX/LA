package com.xiaohe.mapper;

import java.util.List;

import com.xiaohe.po.PointCustom;
import com.xiaohe.po.UsersQueryVo;

public interface PointMapperCustom {

	List<PointCustom> searchUsersInPoint(PointCustom pointCustom);

	public int queryPointCount();

	public void deletePointByMoreId(UsersQueryVo usersQueryVo);

}
