package com.xiaohe.mapper;

import java.util.List;

import com.xiaohe.po.AssUserShopVo;
import com.xiaohe.po.AssessCustom;
import com.xiaohe.po.AssessQueryVo;

public interface AssUserShopMapperCustom {

	public List<AssUserShopVo> searchAss()throws Exception;
	
	public List<AssessCustom> searchAssess()throws Exception;
	
	public int queryAssessAllCount()throws Exception;

	public void deleteass(Integer assess_aid)throws Exception;

	public void DeleteMoreById(AssessQueryVo assessQueryVo)throws Exception;

	

}
