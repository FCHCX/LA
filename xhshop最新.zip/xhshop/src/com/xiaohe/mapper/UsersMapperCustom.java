package com.xiaohe.mapper;

import java.util.List;

import com.xiaohe.po.UserinfoCustom;
import com.xiaohe.po.UsersCustom;
import com.xiaohe.po.UsersQueryVo;

public interface UsersMapperCustom {

	public void addMember(UsersQueryVo usersQueryVo);

	public void deleteMoreMember(UsersQueryVo usersQueryVo);

	public List<UserinfoCustom> searchUsers(UsersQueryVo usersQueryVo);

	public void addMemberInfo(UsersQueryVo usersQueryVo);

	public void deleteMoreMember2(UsersQueryVo usersQueryVo);

	public int queryMember(UsersQueryVo usersQueryVo);
	
	public int selectUsersCount();

	public void updateUsers1(UsersQueryVo usersQueryVo);

	public void updateUsers2(UsersQueryVo usersQueryVo);

	public UsersQueryVo findUsers(String uname);

	

}
