package com.xiaohe.po;

import java.util.List;

public class ControllersQueryVo {

	private ControllersCustom controllersCustom;
	
	private List<Integer> managerId;

	public void setManagerId(List<Integer> managerId) {
		this.managerId = managerId;
	}

	@Override
	public String toString() {
		return "ControllersQueryVo [controllersCustom=" + controllersCustom
				+ ", managerId=" + managerId + "]";
	}

	public ControllersCustom getControllersCustom() {
		return controllersCustom;
	}

	public void setControllersCustom(ControllersCustom controllersCustom) {
		this.controllersCustom = controllersCustom;
	}

	
	
}
