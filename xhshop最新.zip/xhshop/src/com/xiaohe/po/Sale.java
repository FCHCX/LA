package com.xiaohe.po;

public class Sale {
    private Integer soid;

    private Integer sodid;

    private Integer socount;

    private Float ssales;

    public Integer getSoid() {
        return soid;
    }

    public void setSoid(Integer soid) {
        this.soid = soid;
    }

    public Integer getSodid() {
        return sodid;
    }

    public void setSodid(Integer sodid) {
        this.sodid = sodid;
    }

    public Integer getSocount() {
        return socount;
    }

    public void setSocount(Integer socount) {
        this.socount = socount;
    }

    public Float getSsales() {
        return ssales;
    }

    public void setSsales(Float ssales) {
        this.ssales = ssales;
    }
}