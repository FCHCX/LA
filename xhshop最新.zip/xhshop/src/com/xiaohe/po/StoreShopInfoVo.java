package com.xiaohe.po;

public class StoreShopInfoVo extends Store{
	
	private ShopinfoCustom shopinfoCustom;
	
    private String sname;

    private Integer snum;

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Integer getSnum() {
		return snum;
	}

	public void setSnum(Integer snum) {
		this.snum = snum;
	}

	public ShopinfoCustom getShopinfoCustom() {
		return shopinfoCustom;
	}

	public void setShopinfoCustom(ShopinfoCustom shopinfoCustom) {
		this.shopinfoCustom = shopinfoCustom;
	}

}
