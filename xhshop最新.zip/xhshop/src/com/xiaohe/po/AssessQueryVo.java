package com.xiaohe.po;

import java.util.List;

public class AssessQueryVo {
	
	private Assess assess;
	
	private List<Integer> ids;

	public Assess getAssess() {
		return assess;
	}

	public void setAssess(Assess assess) {
		this.assess = assess;
	}

	public List<Integer> getIds() {
		return ids;
	}

	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}
	
	
	

}
