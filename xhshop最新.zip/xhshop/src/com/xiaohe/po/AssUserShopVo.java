package com.xiaohe.po;

public class AssUserShopVo extends Assess{
	
	private Shopinfo shopinfo;
	
	
	private Users users;
	
	private String uname;
	
	 private String sname;

	public Shopinfo getShopinfo() {
		return shopinfo;
	}

	public void setShopinfo(Shopinfo shopinfo) {
		this.shopinfo = shopinfo;
	}

	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}
	 

}