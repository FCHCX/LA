package com.xiaohe.po;

import java.util.List;

public class UsersQueryVo {
	
	private String uname;

    private String upwd;
    
    //新增属性page_name,用于获取待修改的用户名
    private String page_name;
    
    //积分表存入多个id批量删除
    private List<Integer> usersPoint;
    
    
    
    public List<Integer> getUsersPoint() {
		return usersPoint;
	}
	public void setUsersPoint(List<Integer> usersPoint) {
		this.usersPoint = usersPoint;
	}
	public String getPage_name() {
		return page_name;
	}
	public void setPage_name(String page_name) {
		this.page_name = page_name;
	}
	@Override
	public String toString() {
		return "UsersQueryVo [uname=" + uname + ", upwd=" + upwd
				+ ", page_name=" + page_name + ", usersPoint=" + usersPoint
				+ ", ufuname=" + ufuname + ", ufsex=" + ufsex + ", ufsheng="
				+ ufsheng + ", ufshi=" + ufshi + ", ufphone=" + ufphone
				+ ", ufname=" + ufname + ", uqustion=" + uqustion
				+ ", uanswer=" + uanswer + ", uaddress=" + uaddress
				+ ", uplace=" + uplace + ", usersCustom=" + usersCustom
				+ ", meb=" + meb + ", userinfoCustom=" + userinfoCustom
				+ ", updateName=" + updateName + "]";
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUpwd() {
		return upwd;
	}
	public void setUpwd(String upwd) {
		this.upwd = upwd;
	}
	public String getUfuname() {
		return ufuname;
	}
	public void setUfuname(String ufuname) {
		this.ufuname = ufuname;
	}
	public String getUfsex() {
		return ufsex;
	}
	public void setUfsex(String ufsex) {
		this.ufsex = ufsex;
	}
	public String getUfsheng() {
		return ufsheng;
	}
	public void setUfsheng(String ufsheng) {
		this.ufsheng = ufsheng;
	}
	public String getUfshi() {
		return ufshi;
	}
	public void setUfshi(String ufshi) {
		this.ufshi = ufshi;
	}
	public String getUfphone() {
		return ufphone;
	}
	public void setUfphone(String ufphone) {
		this.ufphone = ufphone;
	}
	public String getUfname() {
		return ufname;
	}
	public void setUfname(String ufname) {
		this.ufname = ufname;
	}
	public String getUqustion() {
		return uqustion;
	}
	public void setUqustion(String uqustion) {
		this.uqustion = uqustion;
	}
	public String getUanswer() {
		return uanswer;
	}
	public void setUanswer(String uanswer) {
		this.uanswer = uanswer;
	}
	public Integer getUaddress() {
		return uaddress;
	}
	public void setUaddress(Integer uaddress) {
		this.uaddress = uaddress;
	}
	public String getUplace() {
		return uplace;
	}
	public void setUplace(String uplace) {
		this.uplace = uplace;
	}
	private String ufuname;

    private String ufsex;

    private String ufsheng;

    private String ufshi;

    private String ufphone;

    private String ufname;

    private String uqustion;

    private String uanswer;

    private Integer uaddress;

    private String uplace;
	
	
	
//	private Users users;
	private UsersCustom usersCustom;
	private List<String> meb;
	private UserinfoCustom userinfoCustom;
//	private Userinfo userinfo;
	//传入页面用户名
	private String updateName;
	public String getUpdateName() {
		return updateName;
	}
	public void setUpdateName(String updateName) {
		this.updateName = updateName;
	}
	public UsersCustom getUsersCustom() {
		return usersCustom;
	}
	public void setUsersCustom(UsersCustom usersCustom) {
		this.usersCustom = usersCustom;
	}
	public List<String> getMeb() {
		return meb;
	}
	public void setMeb(List<String> meb) {
		this.meb = meb;
	}
	public UserinfoCustom getUserinfoCustom() {
		return userinfoCustom;
	}
	public void setUserinfoCustom(UserinfoCustom userinfoCustom) {
		this.userinfoCustom = userinfoCustom;
	}
//	public Userinfo getUserinfo() {
//		return userinfo;
//	}
//	public void setUserinfo(Userinfo userinfo) {
//		this.userinfo = userinfo;
//	}
//	@Override
//	public String toString() {
//		return "UsersQueryVo [users=" + users + ", usersCustom=" + usersCustom
//				+ ", meb=" + meb + ", userinfoCustom=" + userinfoCustom
//				+ ", userinfo=" + userinfo + "]";
//	}
//	public List<String> getMeb() {
//		return meb;
//	}
//	public void setMeb(List<String> meb) {
//		this.meb = meb;
//	}
//	public Users getUsers() {
//		return users;
//	}
//	public void setUsers(Users users) {
//		this.users = users;
//	}
//	public UsersCustom getUsersCustom() {
//		return usersCustom;
//	}
//	public void setUsersCustom(UsersCustom usersCustom) {
//		this.usersCustom = usersCustom;
//	}
	
	
	
}
