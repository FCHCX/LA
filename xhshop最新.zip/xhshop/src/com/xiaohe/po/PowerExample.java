package com.xiaohe.po;

import java.util.ArrayList;
import java.util.List;

public class PowerExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public PowerExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andPidIsNull() {
            addCriterion("Pid is null");
            return (Criteria) this;
        }

        public Criteria andPidIsNotNull() {
            addCriterion("Pid is not null");
            return (Criteria) this;
        }

        public Criteria andPidEqualTo(Integer value) {
            addCriterion("Pid =", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidNotEqualTo(Integer value) {
            addCriterion("Pid <>", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidGreaterThan(Integer value) {
            addCriterion("Pid >", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidGreaterThanOrEqualTo(Integer value) {
            addCriterion("Pid >=", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidLessThan(Integer value) {
            addCriterion("Pid <", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidLessThanOrEqualTo(Integer value) {
            addCriterion("Pid <=", value, "pid");
            return (Criteria) this;
        }

        public Criteria andPidIn(List<Integer> values) {
            addCriterion("Pid in", values, "pid");
            return (Criteria) this;
        }

        public Criteria andPidNotIn(List<Integer> values) {
            addCriterion("Pid not in", values, "pid");
            return (Criteria) this;
        }

        public Criteria andPidBetween(Integer value1, Integer value2) {
            addCriterion("Pid between", value1, value2, "pid");
            return (Criteria) this;
        }

        public Criteria andPidNotBetween(Integer value1, Integer value2) {
            addCriterion("Pid not between", value1, value2, "pid");
            return (Criteria) this;
        }

        public Criteria andPcidIsNull() {
            addCriterion("Pcid is null");
            return (Criteria) this;
        }

        public Criteria andPcidIsNotNull() {
            addCriterion("Pcid is not null");
            return (Criteria) this;
        }

        public Criteria andPcidEqualTo(Integer value) {
            addCriterion("Pcid =", value, "pcid");
            return (Criteria) this;
        }

        public Criteria andPcidNotEqualTo(Integer value) {
            addCriterion("Pcid <>", value, "pcid");
            return (Criteria) this;
        }

        public Criteria andPcidGreaterThan(Integer value) {
            addCriterion("Pcid >", value, "pcid");
            return (Criteria) this;
        }

        public Criteria andPcidGreaterThanOrEqualTo(Integer value) {
            addCriterion("Pcid >=", value, "pcid");
            return (Criteria) this;
        }

        public Criteria andPcidLessThan(Integer value) {
            addCriterion("Pcid <", value, "pcid");
            return (Criteria) this;
        }

        public Criteria andPcidLessThanOrEqualTo(Integer value) {
            addCriterion("Pcid <=", value, "pcid");
            return (Criteria) this;
        }

        public Criteria andPcidIn(List<Integer> values) {
            addCriterion("Pcid in", values, "pcid");
            return (Criteria) this;
        }

        public Criteria andPcidNotIn(List<Integer> values) {
            addCriterion("Pcid not in", values, "pcid");
            return (Criteria) this;
        }

        public Criteria andPcidBetween(Integer value1, Integer value2) {
            addCriterion("Pcid between", value1, value2, "pcid");
            return (Criteria) this;
        }

        public Criteria andPcidNotBetween(Integer value1, Integer value2) {
            addCriterion("Pcid not between", value1, value2, "pcid");
            return (Criteria) this;
        }

        public Criteria andPwnameIsNull() {
            addCriterion("Pwname is null");
            return (Criteria) this;
        }

        public Criteria andPwnameIsNotNull() {
            addCriterion("Pwname is not null");
            return (Criteria) this;
        }

        public Criteria andPwnameEqualTo(String value) {
            addCriterion("Pwname =", value, "pwname");
            return (Criteria) this;
        }

        public Criteria andPwnameNotEqualTo(String value) {
            addCriterion("Pwname <>", value, "pwname");
            return (Criteria) this;
        }

        public Criteria andPwnameGreaterThan(String value) {
            addCriterion("Pwname >", value, "pwname");
            return (Criteria) this;
        }

        public Criteria andPwnameGreaterThanOrEqualTo(String value) {
            addCriterion("Pwname >=", value, "pwname");
            return (Criteria) this;
        }

        public Criteria andPwnameLessThan(String value) {
            addCriterion("Pwname <", value, "pwname");
            return (Criteria) this;
        }

        public Criteria andPwnameLessThanOrEqualTo(String value) {
            addCriterion("Pwname <=", value, "pwname");
            return (Criteria) this;
        }

        public Criteria andPwnameLike(String value) {
            addCriterion("Pwname like", value, "pwname");
            return (Criteria) this;
        }

        public Criteria andPwnameNotLike(String value) {
            addCriterion("Pwname not like", value, "pwname");
            return (Criteria) this;
        }

        public Criteria andPwnameIn(List<String> values) {
            addCriterion("Pwname in", values, "pwname");
            return (Criteria) this;
        }

        public Criteria andPwnameNotIn(List<String> values) {
            addCriterion("Pwname not in", values, "pwname");
            return (Criteria) this;
        }

        public Criteria andPwnameBetween(String value1, String value2) {
            addCriterion("Pwname between", value1, value2, "pwname");
            return (Criteria) this;
        }

        public Criteria andPwnameNotBetween(String value1, String value2) {
            addCriterion("Pwname not between", value1, value2, "pwname");
            return (Criteria) this;
        }

        public Criteria andPdetailIsNull() {
            addCriterion("Pdetail is null");
            return (Criteria) this;
        }

        public Criteria andPdetailIsNotNull() {
            addCriterion("Pdetail is not null");
            return (Criteria) this;
        }

        public Criteria andPdetailEqualTo(String value) {
            addCriterion("Pdetail =", value, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPdetailNotEqualTo(String value) {
            addCriterion("Pdetail <>", value, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPdetailGreaterThan(String value) {
            addCriterion("Pdetail >", value, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPdetailGreaterThanOrEqualTo(String value) {
            addCriterion("Pdetail >=", value, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPdetailLessThan(String value) {
            addCriterion("Pdetail <", value, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPdetailLessThanOrEqualTo(String value) {
            addCriterion("Pdetail <=", value, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPdetailLike(String value) {
            addCriterion("Pdetail like", value, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPdetailNotLike(String value) {
            addCriterion("Pdetail not like", value, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPdetailIn(List<String> values) {
            addCriterion("Pdetail in", values, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPdetailNotIn(List<String> values) {
            addCriterion("Pdetail not in", values, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPdetailBetween(String value1, String value2) {
            addCriterion("Pdetail between", value1, value2, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPdetailNotBetween(String value1, String value2) {
            addCriterion("Pdetail not between", value1, value2, "pdetail");
            return (Criteria) this;
        }

        public Criteria andPmenuIsNull() {
            addCriterion("Pmenu is null");
            return (Criteria) this;
        }

        public Criteria andPmenuIsNotNull() {
            addCriterion("Pmenu is not null");
            return (Criteria) this;
        }

        public Criteria andPmenuEqualTo(String value) {
            addCriterion("Pmenu =", value, "pmenu");
            return (Criteria) this;
        }

        public Criteria andPmenuNotEqualTo(String value) {
            addCriterion("Pmenu <>", value, "pmenu");
            return (Criteria) this;
        }

        public Criteria andPmenuGreaterThan(String value) {
            addCriterion("Pmenu >", value, "pmenu");
            return (Criteria) this;
        }

        public Criteria andPmenuGreaterThanOrEqualTo(String value) {
            addCriterion("Pmenu >=", value, "pmenu");
            return (Criteria) this;
        }

        public Criteria andPmenuLessThan(String value) {
            addCriterion("Pmenu <", value, "pmenu");
            return (Criteria) this;
        }

        public Criteria andPmenuLessThanOrEqualTo(String value) {
            addCriterion("Pmenu <=", value, "pmenu");
            return (Criteria) this;
        }

        public Criteria andPmenuLike(String value) {
            addCriterion("Pmenu like", value, "pmenu");
            return (Criteria) this;
        }

        public Criteria andPmenuNotLike(String value) {
            addCriterion("Pmenu not like", value, "pmenu");
            return (Criteria) this;
        }

        public Criteria andPmenuIn(List<String> values) {
            addCriterion("Pmenu in", values, "pmenu");
            return (Criteria) this;
        }

        public Criteria andPmenuNotIn(List<String> values) {
            addCriterion("Pmenu not in", values, "pmenu");
            return (Criteria) this;
        }

        public Criteria andPmenuBetween(String value1, String value2) {
            addCriterion("Pmenu between", value1, value2, "pmenu");
            return (Criteria) this;
        }

        public Criteria andPmenuNotBetween(String value1, String value2) {
            addCriterion("Pmenu not between", value1, value2, "pmenu");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}