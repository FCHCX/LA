package com.xiaohe.po;

public class NoticeControllersCustom extends Notice{
	
	private Controllers controllers;

	public Controllers getControllers() {
		return controllers;
	}

	public void setControllers(Controllers controllers) {
		this.controllers = controllers;
	}

	@Override
	public String toString() {
		return "NoticeControllersCustom [controllers=" + controllers + "]";
	}
	
	
	
}
