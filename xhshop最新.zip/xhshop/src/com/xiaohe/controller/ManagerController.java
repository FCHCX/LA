package com.xiaohe.controller;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.xiaohe.po.ControllersCustom;
import com.xiaohe.po.PowerCustom;
import com.xiaohe.po.PowerQueryVo;
import com.xiaohe.service.ManagerService;


@Controller
@RequestMapping("/manager")


public class ManagerController {
	@Autowired
	private ManagerService managerService;
	
	//添加管理员
	@RequestMapping("/addManager")
	public String addManager(ControllersCustom controllersCustom){
		
		managerService.addManager(controllersCustom);
		return "redirect:/manager/queryManager.action";
		
		
	}
	
	//按用户名进行查询管理员用户,为空默认查询全部
	
	@RequestMapping("/queryManager")
	public String queryManager( ControllersCustom controllersCustom,Model model){
		int count = managerService.queryManagerCount();
		model.addAttribute("count", count);
		List<ControllersCustom> managerList = managerService.queryManager(controllersCustom);
		model.addAttribute("managerList", managerList);
		
		return "administrator";
		
		
	}
	
	
	//单个删除管理员
	@RequestMapping("/deleteManager")
	public String deleteManager(Integer mid){
		
		managerService.deleteManager(mid);
		return "administrator";
		
		
		
	}
	
	//批量删除管理员
	@RequestMapping("/deleteMoreManager")
	public String deleteMoreManager(Integer [] mid){
		
		managerService.deleteMoreManager(mid);
		return "administrator";
		
		
		
	}
	
	//修改管理员信息跳转修改页面
	@RequestMapping("/updateEditManager")
	public String updateEditManager(Integer cid,Model model){
		//先把对应id的管理员查询出来，跳转页面并回显
		
		ControllersCustom controllersCustom = managerService.queryEditManager(cid);
		model.addAttribute("manager", controllersCustom);
		
		return "manager-update";
		
		
	}
	
	//修改管理员信息提交返回
	@RequestMapping("/managerSubmit")
	public String managerSubmit(ControllersCustom controllersCustom){
		
		managerService.managerSubmit(controllersCustom);
		
		return "redirect:/manager/queryAllManagerByGroup.action";
		
		
		
	}
	
	
	//查询所有管理员用户放到model并在页面显示
	@RequestMapping("/queryAllManager")
	public String queryAllManager(Model model){
		
		List<ControllersCustom> managerList = managerService.queryAllManager();
		model.addAttribute("managerList", managerList);
		return "Competence";
		
		
	}
	
	
	
	//添加权限,传两个表的值，用Vo接收
	@RequestMapping("/addPower")
	public String addPower(PowerQueryVo powerQueryVo){
		
		managerService.addPower(powerQueryVo);
		
		
		return "Competence";
		
		
	}
	
	
	
	//权限操作查询所有管理员
	@RequestMapping("/queryAllManagerByGroup")
	public String queryAllManagerByGroup(Model model){
		
		List<ControllersCustom> managerList = managerService.queryAllManagerByGroup();
		int count = managerService.queryManagerCount();
		model.addAttribute("count", count);
		model.addAttribute("managerList", managerList);
		
		return "admin_Competence";
		
		
		
	}
	
	
	//权限管理单个删除管理员
		@RequestMapping("/deletePowerManager")
		public String deletePowerManager(Integer mid){
			
			managerService.deleteManager(mid);
			return "redirect:/manager/queryAllManagerByGroup.action";
			
			
			
		}
		
	//权限管理批量删除管理员
		
		@RequestMapping("/deleteMorePowerManager")
		public String deleteMorePowerManager(Integer [] mid){
			
			managerService.deleteMoreManager(mid);
			return "redirect:/manager/queryAllManagerByGroup.action";
			
			
		}
		
	//进入权限修改页面等待提交
		@RequestMapping("/editManager")
		public String editManager(Model model,@RequestParam(value="cid",required=true ) Integer cid){
			
			/*List<PowerCustom> powerList= managerService.findManagerPowerById(cid);*/
			
			/*model.addAttribute("powerList", powerList);*/
			
			/*return "Competence";*/
			
			model.addAttribute("cid", cid);
			
			return "updateCompetence";
			
			
		}
		
		
	//修改提交，点击保存按钮后，根据id先删除原先用户的所有权限，
	//再向权限表中插入修改过后的权限以完成权限修改
		
		@RequestMapping("/updatePower")
		
		public String updatePower(Integer cid,PowerQueryVo powerQueryVo){
			
			if(cid!=null&&powerQueryVo!=null){
			int count = managerService.selectPowerCount(cid);
			managerService.updatePower(powerQueryVo,count,cid);
			return "redirect:/manager/queryAllManagerByGroup.action";
			}
			return "redirect:/manager/queryAllManagerByGroup.action";
		}
		
	

}
