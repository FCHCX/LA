package com.xiaohe.po;

import java.util.ArrayList;
import java.util.List;

public class ControllersExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public ControllersExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCidIsNull() {
            addCriterion("Cid is null");
            return (Criteria) this;
        }

        public Criteria andCidIsNotNull() {
            addCriterion("Cid is not null");
            return (Criteria) this;
        }

        public Criteria andCidEqualTo(Integer value) {
            addCriterion("Cid =", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidNotEqualTo(Integer value) {
            addCriterion("Cid <>", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidGreaterThan(Integer value) {
            addCriterion("Cid >", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidGreaterThanOrEqualTo(Integer value) {
            addCriterion("Cid >=", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidLessThan(Integer value) {
            addCriterion("Cid <", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidLessThanOrEqualTo(Integer value) {
            addCriterion("Cid <=", value, "cid");
            return (Criteria) this;
        }

        public Criteria andCidIn(List<Integer> values) {
            addCriterion("Cid in", values, "cid");
            return (Criteria) this;
        }

        public Criteria andCidNotIn(List<Integer> values) {
            addCriterion("Cid not in", values, "cid");
            return (Criteria) this;
        }

        public Criteria andCidBetween(Integer value1, Integer value2) {
            addCriterion("Cid between", value1, value2, "cid");
            return (Criteria) this;
        }

        public Criteria andCidNotBetween(Integer value1, Integer value2) {
            addCriterion("Cid not between", value1, value2, "cid");
            return (Criteria) this;
        }

        public Criteria andCnameIsNull() {
            addCriterion("Cname is null");
            return (Criteria) this;
        }

        public Criteria andCnameIsNotNull() {
            addCriterion("Cname is not null");
            return (Criteria) this;
        }

        public Criteria andCnameEqualTo(String value) {
            addCriterion("Cname =", value, "cname");
            return (Criteria) this;
        }

        public Criteria andCnameNotEqualTo(String value) {
            addCriterion("Cname <>", value, "cname");
            return (Criteria) this;
        }

        public Criteria andCnameGreaterThan(String value) {
            addCriterion("Cname >", value, "cname");
            return (Criteria) this;
        }

        public Criteria andCnameGreaterThanOrEqualTo(String value) {
            addCriterion("Cname >=", value, "cname");
            return (Criteria) this;
        }

        public Criteria andCnameLessThan(String value) {
            addCriterion("Cname <", value, "cname");
            return (Criteria) this;
        }

        public Criteria andCnameLessThanOrEqualTo(String value) {
            addCriterion("Cname <=", value, "cname");
            return (Criteria) this;
        }

        public Criteria andCnameLike(String value) {
            addCriterion("Cname like", value, "cname");
            return (Criteria) this;
        }

        public Criteria andCnameNotLike(String value) {
            addCriterion("Cname not like", value, "cname");
            return (Criteria) this;
        }

        public Criteria andCnameIn(List<String> values) {
            addCriterion("Cname in", values, "cname");
            return (Criteria) this;
        }

        public Criteria andCnameNotIn(List<String> values) {
            addCriterion("Cname not in", values, "cname");
            return (Criteria) this;
        }

        public Criteria andCnameBetween(String value1, String value2) {
            addCriterion("Cname between", value1, value2, "cname");
            return (Criteria) this;
        }

        public Criteria andCnameNotBetween(String value1, String value2) {
            addCriterion("Cname not between", value1, value2, "cname");
            return (Criteria) this;
        }

        public Criteria andCpwdIsNull() {
            addCriterion("Cpwd is null");
            return (Criteria) this;
        }

        public Criteria andCpwdIsNotNull() {
            addCriterion("Cpwd is not null");
            return (Criteria) this;
        }

        public Criteria andCpwdEqualTo(String value) {
            addCriterion("Cpwd =", value, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCpwdNotEqualTo(String value) {
            addCriterion("Cpwd <>", value, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCpwdGreaterThan(String value) {
            addCriterion("Cpwd >", value, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCpwdGreaterThanOrEqualTo(String value) {
            addCriterion("Cpwd >=", value, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCpwdLessThan(String value) {
            addCriterion("Cpwd <", value, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCpwdLessThanOrEqualTo(String value) {
            addCriterion("Cpwd <=", value, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCpwdLike(String value) {
            addCriterion("Cpwd like", value, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCpwdNotLike(String value) {
            addCriterion("Cpwd not like", value, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCpwdIn(List<String> values) {
            addCriterion("Cpwd in", values, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCpwdNotIn(List<String> values) {
            addCriterion("Cpwd not in", values, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCpwdBetween(String value1, String value2) {
            addCriterion("Cpwd between", value1, value2, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCpwdNotBetween(String value1, String value2) {
            addCriterion("Cpwd not between", value1, value2, "cpwd");
            return (Criteria) this;
        }

        public Criteria andCsexIsNull() {
            addCriterion("Csex is null");
            return (Criteria) this;
        }

        public Criteria andCsexIsNotNull() {
            addCriterion("Csex is not null");
            return (Criteria) this;
        }

        public Criteria andCsexEqualTo(String value) {
            addCriterion("Csex =", value, "csex");
            return (Criteria) this;
        }

        public Criteria andCsexNotEqualTo(String value) {
            addCriterion("Csex <>", value, "csex");
            return (Criteria) this;
        }

        public Criteria andCsexGreaterThan(String value) {
            addCriterion("Csex >", value, "csex");
            return (Criteria) this;
        }

        public Criteria andCsexGreaterThanOrEqualTo(String value) {
            addCriterion("Csex >=", value, "csex");
            return (Criteria) this;
        }

        public Criteria andCsexLessThan(String value) {
            addCriterion("Csex <", value, "csex");
            return (Criteria) this;
        }

        public Criteria andCsexLessThanOrEqualTo(String value) {
            addCriterion("Csex <=", value, "csex");
            return (Criteria) this;
        }

        public Criteria andCsexLike(String value) {
            addCriterion("Csex like", value, "csex");
            return (Criteria) this;
        }

        public Criteria andCsexNotLike(String value) {
            addCriterion("Csex not like", value, "csex");
            return (Criteria) this;
        }

        public Criteria andCsexIn(List<String> values) {
            addCriterion("Csex in", values, "csex");
            return (Criteria) this;
        }

        public Criteria andCsexNotIn(List<String> values) {
            addCriterion("Csex not in", values, "csex");
            return (Criteria) this;
        }

        public Criteria andCsexBetween(String value1, String value2) {
            addCriterion("Csex between", value1, value2, "csex");
            return (Criteria) this;
        }

        public Criteria andCsexNotBetween(String value1, String value2) {
            addCriterion("Csex not between", value1, value2, "csex");
            return (Criteria) this;
        }

        public Criteria andCphoneIsNull() {
            addCriterion("Cphone is null");
            return (Criteria) this;
        }

        public Criteria andCphoneIsNotNull() {
            addCriterion("Cphone is not null");
            return (Criteria) this;
        }

        public Criteria andCphoneEqualTo(String value) {
            addCriterion("Cphone =", value, "cphone");
            return (Criteria) this;
        }

        public Criteria andCphoneNotEqualTo(String value) {
            addCriterion("Cphone <>", value, "cphone");
            return (Criteria) this;
        }

        public Criteria andCphoneGreaterThan(String value) {
            addCriterion("Cphone >", value, "cphone");
            return (Criteria) this;
        }

        public Criteria andCphoneGreaterThanOrEqualTo(String value) {
            addCriterion("Cphone >=", value, "cphone");
            return (Criteria) this;
        }

        public Criteria andCphoneLessThan(String value) {
            addCriterion("Cphone <", value, "cphone");
            return (Criteria) this;
        }

        public Criteria andCphoneLessThanOrEqualTo(String value) {
            addCriterion("Cphone <=", value, "cphone");
            return (Criteria) this;
        }

        public Criteria andCphoneLike(String value) {
            addCriterion("Cphone like", value, "cphone");
            return (Criteria) this;
        }

        public Criteria andCphoneNotLike(String value) {
            addCriterion("Cphone not like", value, "cphone");
            return (Criteria) this;
        }

        public Criteria andCphoneIn(List<String> values) {
            addCriterion("Cphone in", values, "cphone");
            return (Criteria) this;
        }

        public Criteria andCphoneNotIn(List<String> values) {
            addCriterion("Cphone not in", values, "cphone");
            return (Criteria) this;
        }

        public Criteria andCphoneBetween(String value1, String value2) {
            addCriterion("Cphone between", value1, value2, "cphone");
            return (Criteria) this;
        }

        public Criteria andCphoneNotBetween(String value1, String value2) {
            addCriterion("Cphone not between", value1, value2, "cphone");
            return (Criteria) this;
        }

        public Criteria andCremarkIsNull() {
            addCriterion("Cremark is null");
            return (Criteria) this;
        }

        public Criteria andCremarkIsNotNull() {
            addCriterion("Cremark is not null");
            return (Criteria) this;
        }

        public Criteria andCremarkEqualTo(String value) {
            addCriterion("Cremark =", value, "cremark");
            return (Criteria) this;
        }

        public Criteria andCremarkNotEqualTo(String value) {
            addCriterion("Cremark <>", value, "cremark");
            return (Criteria) this;
        }

        public Criteria andCremarkGreaterThan(String value) {
            addCriterion("Cremark >", value, "cremark");
            return (Criteria) this;
        }

        public Criteria andCremarkGreaterThanOrEqualTo(String value) {
            addCriterion("Cremark >=", value, "cremark");
            return (Criteria) this;
        }

        public Criteria andCremarkLessThan(String value) {
            addCriterion("Cremark <", value, "cremark");
            return (Criteria) this;
        }

        public Criteria andCremarkLessThanOrEqualTo(String value) {
            addCriterion("Cremark <=", value, "cremark");
            return (Criteria) this;
        }

        public Criteria andCremarkLike(String value) {
            addCriterion("Cremark like", value, "cremark");
            return (Criteria) this;
        }

        public Criteria andCremarkNotLike(String value) {
            addCriterion("Cremark not like", value, "cremark");
            return (Criteria) this;
        }

        public Criteria andCremarkIn(List<String> values) {
            addCriterion("Cremark in", values, "cremark");
            return (Criteria) this;
        }

        public Criteria andCremarkNotIn(List<String> values) {
            addCriterion("Cremark not in", values, "cremark");
            return (Criteria) this;
        }

        public Criteria andCremarkBetween(String value1, String value2) {
            addCriterion("Cremark between", value1, value2, "cremark");
            return (Criteria) this;
        }

        public Criteria andCremarkNotBetween(String value1, String value2) {
            addCriterion("Cremark not between", value1, value2, "cremark");
            return (Criteria) this;
        }

        public Criteria andCroleIsNull() {
            addCriterion("Crole is null");
            return (Criteria) this;
        }

        public Criteria andCroleIsNotNull() {
            addCriterion("Crole is not null");
            return (Criteria) this;
        }

        public Criteria andCroleEqualTo(String value) {
            addCriterion("Crole =", value, "crole");
            return (Criteria) this;
        }

        public Criteria andCroleNotEqualTo(String value) {
            addCriterion("Crole <>", value, "crole");
            return (Criteria) this;
        }

        public Criteria andCroleGreaterThan(String value) {
            addCriterion("Crole >", value, "crole");
            return (Criteria) this;
        }

        public Criteria andCroleGreaterThanOrEqualTo(String value) {
            addCriterion("Crole >=", value, "crole");
            return (Criteria) this;
        }

        public Criteria andCroleLessThan(String value) {
            addCriterion("Crole <", value, "crole");
            return (Criteria) this;
        }

        public Criteria andCroleLessThanOrEqualTo(String value) {
            addCriterion("Crole <=", value, "crole");
            return (Criteria) this;
        }

        public Criteria andCroleLike(String value) {
            addCriterion("Crole like", value, "crole");
            return (Criteria) this;
        }

        public Criteria andCroleNotLike(String value) {
            addCriterion("Crole not like", value, "crole");
            return (Criteria) this;
        }

        public Criteria andCroleIn(List<String> values) {
            addCriterion("Crole in", values, "crole");
            return (Criteria) this;
        }

        public Criteria andCroleNotIn(List<String> values) {
            addCriterion("Crole not in", values, "crole");
            return (Criteria) this;
        }

        public Criteria andCroleBetween(String value1, String value2) {
            addCriterion("Crole between", value1, value2, "crole");
            return (Criteria) this;
        }

        public Criteria andCroleNotBetween(String value1, String value2) {
            addCriterion("Crole not between", value1, value2, "crole");
            return (Criteria) this;
        }

        public Criteria andCemailIsNull() {
            addCriterion("Cemail is null");
            return (Criteria) this;
        }

        public Criteria andCemailIsNotNull() {
            addCriterion("Cemail is not null");
            return (Criteria) this;
        }

        public Criteria andCemailEqualTo(String value) {
            addCriterion("Cemail =", value, "cemail");
            return (Criteria) this;
        }

        public Criteria andCemailNotEqualTo(String value) {
            addCriterion("Cemail <>", value, "cemail");
            return (Criteria) this;
        }

        public Criteria andCemailGreaterThan(String value) {
            addCriterion("Cemail >", value, "cemail");
            return (Criteria) this;
        }

        public Criteria andCemailGreaterThanOrEqualTo(String value) {
            addCriterion("Cemail >=", value, "cemail");
            return (Criteria) this;
        }

        public Criteria andCemailLessThan(String value) {
            addCriterion("Cemail <", value, "cemail");
            return (Criteria) this;
        }

        public Criteria andCemailLessThanOrEqualTo(String value) {
            addCriterion("Cemail <=", value, "cemail");
            return (Criteria) this;
        }

        public Criteria andCemailLike(String value) {
            addCriterion("Cemail like", value, "cemail");
            return (Criteria) this;
        }

        public Criteria andCemailNotLike(String value) {
            addCriterion("Cemail not like", value, "cemail");
            return (Criteria) this;
        }

        public Criteria andCemailIn(List<String> values) {
            addCriterion("Cemail in", values, "cemail");
            return (Criteria) this;
        }

        public Criteria andCemailNotIn(List<String> values) {
            addCriterion("Cemail not in", values, "cemail");
            return (Criteria) this;
        }

        public Criteria andCemailBetween(String value1, String value2) {
            addCriterion("Cemail between", value1, value2, "cemail");
            return (Criteria) this;
        }

        public Criteria andCemailNotBetween(String value1, String value2) {
            addCriterion("Cemail not between", value1, value2, "cemail");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}