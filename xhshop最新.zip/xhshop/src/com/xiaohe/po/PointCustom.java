package com.xiaohe.po;

public class PointCustom extends Point{

}
