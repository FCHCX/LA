package com.xiaohe.po;

public class ControllersCustom extends Controllers{

}
