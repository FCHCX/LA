package com.xiaohe.po;

import java.util.List;

public class NoticeQueryVo {

	private Notice notice;
	
	private List<Integer> ids;

	public Notice getNotice() {
		return notice;
	}

	public void setNotice(Notice notice) {
		this.notice = notice;
	}

	public List<Integer> getIds() {
		return ids;
	}

	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}
	
	
}
