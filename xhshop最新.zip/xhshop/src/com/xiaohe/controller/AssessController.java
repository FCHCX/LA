package com.xiaohe.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xiaohe.po.AssUserShopVo;
import com.xiaohe.po.AssessCustom;
import com.xiaohe.service.AssessService;



@Controller
@RequestMapping("/assess")
public class AssessController {
	
	@Autowired
	private AssessService assService;
	//评论搜索
	@RequestMapping("/searchassess")
	public String searchItems(Model model) throws Exception{
		List<AssUserShopVo> assessList=assService.searchAss();
		model.addAttribute("assessList", assessList);
		int number = assService.queryAssessAllCount();
		model.addAttribute("number", number);
		return "Guestbook";
	}
	
	//删除评论
	@RequestMapping("/deleteass")
	public String deleteass(Integer assess_aid)throws Exception{
		if(assess_aid!=null){
			assService.deleteass(assess_aid);
			return "redirect:/assess/searchassess.action";
		}
		System.out.println(assess_aid);
		return "redirect:/assess/searchassess.action";
	}
	
	//批量删除评论
	@RequestMapping("/deletemorebyId")
	public String deletemorebyId(Integer [] assess_aid)throws Exception{
		if(assess_aid!=null){
			assService.DeleteMoreById(assess_aid);
			return "redirect:/assess/searchassess.action";
		}
		return "redirect:/assess/searchassess.action";
	}
}
