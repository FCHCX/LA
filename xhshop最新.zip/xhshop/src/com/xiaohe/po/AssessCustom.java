package com.xiaohe.po;

public class AssessCustom extends Shopinfo{
	private Assess assess;

	public Assess getAssess() {
		return assess;
	}

	public void setAssess(Assess assess) {
		this.assess = assess;
	}
	
	

}
