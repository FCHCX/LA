package com.xiaohe.mapper;

import java.util.List;

import com.xiaohe.po.Controllers;
import com.xiaohe.po.ControllersCustom;
import com.xiaohe.po.ControllersQueryVo;
import com.xiaohe.po.PowerCustom;
import com.xiaohe.po.PowerQueryVo;

public interface ControllersMapperCustom {

	public void addManager(ControllersCustom controllersCustom);

	public List<ControllersCustom> queryManager(ControllersCustom controllersCustom);

	public void deleteMoreManager(ControllersQueryVo controllersQueryVo);

	public int queryManagerCount();

	public List<ControllersCustom> queryAllManager();

	public void addPower(PowerQueryVo powerQueryVo);

	public List<ControllersCustom> queryAllManagerByGroup();

	public List<PowerCustom> findManagerPowerById(Integer cid);

	public int selectPowerCount(Integer cid);

	public void deleteMorePower(int count);

	public void addPowerBySingle(PowerQueryVo powerQueryVo);
	
	
	//蒙莞的登录
	public Controllers selectAdmin(Controllers controllers);


}
