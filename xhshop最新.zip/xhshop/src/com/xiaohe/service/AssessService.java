package com.xiaohe.service;

import java.util.List;

import com.xiaohe.po.AssUserShopVo;
import com.xiaohe.po.AssessCustom;

public interface AssessService {

	//搜索评论
	public List<AssUserShopVo> searchAss() throws Exception;
	//查询总评论数
	public int queryAssessAllCount() throws Exception;
	//删除单个评论
	public void deleteass(Integer assess_aid)throws Exception;
	
	public List<AssessCustom> searchAssess()throws Exception;
	//批量删除
	public void DeleteMoreById(Integer[] assess_aid) throws Exception;
	

}
