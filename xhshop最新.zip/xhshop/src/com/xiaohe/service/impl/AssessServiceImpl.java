package com.xiaohe.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.xiaohe.mapper.AssUserShopMapperCustom;
import com.xiaohe.po.AssUserShopVo;
import com.xiaohe.po.AssessCustom;
import com.xiaohe.po.AssessQueryVo;
import com.xiaohe.po.NoticeQueryVo;
import com.xiaohe.service.AssessService;

public class AssessServiceImpl implements AssessService{

	@Autowired
	private AssUserShopMapperCustom assUserShopMapperCustom;
	//搜索评论
	@Override
	public List<AssUserShopVo> searchAss()throws Exception {
		// TODO Auto-generated method stub
		return assUserShopMapperCustom.searchAss();
	}
	@Override
	public List<AssessCustom> searchAssess() throws Exception {
		// TODO Auto-generated method stub
		return assUserShopMapperCustom.searchAssess();
	}

	//查询总评论数
	@Override
	public int queryAssessAllCount() throws Exception {
		// TODO Auto-generated method stub
		return assUserShopMapperCustom.queryAssessAllCount();
	}
	//删除单个评论
	@Override
	public void deleteass(Integer assess_aid) throws Exception {
		// TODO Auto-generated method stub
		assUserShopMapperCustom.deleteass(assess_aid);
	}
	//批量删除
	@Override
	public void DeleteMoreById(Integer[] assess_aid)throws Exception{
		// TODO Auto-generated method stub
		AssessQueryVo assessQueryVo=new AssessQueryVo();
		List<Integer> ids= new ArrayList<Integer>();
		for (int i=0;i<assess_aid.length;i++) {
			ids.add(assess_aid[i]);
		}
		assessQueryVo.setIds(ids);
		assUserShopMapperCustom.DeleteMoreById(assessQueryVo);
	}

}
