package com.xiaohe.po;

public class PowerCustom  extends Power{

}
