package com.xiaohe.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.xiaohe.mapper.PointMapper;
import com.xiaohe.mapper.PointMapperCustom;
import com.xiaohe.mapper.UserinfoMapper;
import com.xiaohe.mapper.UsersMapper;
import com.xiaohe.mapper.UsersMapperCustom;
import com.xiaohe.po.Point;
import com.xiaohe.po.PointCustom;
import com.xiaohe.po.Userinfo;
import com.xiaohe.po.UserinfoCustom;
import com.xiaohe.po.Users;
import com.xiaohe.po.UsersCustom;
import com.xiaohe.po.UsersQueryVo;
import com.xiaohe.service.MemberService;

public class MemberServiceImpl implements MemberService{
	
	@Autowired
	
	private UsersMapper usersMapper;
	@Autowired 
	private UserinfoMapper userinfoMapper;
	
	@Autowired
	private UsersMapperCustom usersMapperCustom;
	
	@Autowired
	private PointMapper pointMapper;
	
	@Autowired
	private PointMapperCustom pointMapperCustom;
	
	@Override
	public void addMember(UsersQueryVo usersQueryVo) {
		// TODO Auto-generated method stub
		usersMapperCustom.addMember(usersQueryVo);
		usersMapperCustom.addMemberInfo(usersQueryVo);
	}

	@Override
	public void deleteMember(String ufuname) {
		// TODO Auto-generated method stub
//		usersMapperCustom.deleteMember(usersCustom);
		//usersMapper.deleteByPrimaryKey(usersCustom.getUname());
//		String name=usersQueryVo.getUserinfoCustom().getUfuname();
//		usersQueryVo.getUsersCustom().setUname(name);
		
		userinfoMapper.deleteByPrimaryKey(ufuname);
		usersMapper.deleteByPrimaryKey(ufuname);
	}

	@Override
	public void deleteMoreMember(String[] member) {
		// TODO Auto-generated method stub
		UsersQueryVo usersQueryVo=new UsersQueryVo();
		List<String> meb=new ArrayList<String>();
		for (int i=0;i<member.length;i++) {
			meb.add(member[i]);
		}
		
		usersQueryVo.setMeb(meb);
		//先删除子表，再删除主表
		usersMapperCustom.deleteMoreMember(usersQueryVo);
		usersMapperCustom.deleteMoreMember2(usersQueryVo);
	}

	@Override
	public List<UserinfoCustom> searchUsers(UsersQueryVo usersQueryVo) {
		// TODO Auto-generated method stub
		return usersMapperCustom.searchUsers(usersQueryVo);
		
	}

	@Override
	public void updateUsers(UsersQueryVo usersQueryVo) {
		// TODO Auto-generated method stub
		//usersMapperCustom.updateUsers(usersCustom);

		usersMapperCustom.updateUsers2(usersQueryVo);
//		System.out.println(t/s);
		usersMapperCustom.updateUsers1(usersQueryVo);
	}
	//以下方法暂时不用
	@Override
	public void addMemberInfo(UsersQueryVo usersQueryVo) {
		// TODO Auto-generated method stub
//		String ufname=usersQueryVo.getUsersCustom().getUname();
//		usersQueryVo.getUserinfoCustom().setUfname(ufname);
		usersMapperCustom.addMemberInfo(usersQueryVo);
	}

	@Override
	public int queryMember(UsersQueryVo usersQueryVo) {
		// TODO Auto-generated method stub
		return 	usersMapperCustom.queryMember(usersQueryVo);
		
		
	}

	@Override
	public int selectUsersCount() {
		// TODO Auto-generated method stub
		return usersMapperCustom.selectUsersCount();
	}

	@Override
	public UsersQueryVo findUsers(String uname) {
		// TODO Auto-generated method stub
		return usersMapperCustom.findUsers(uname);
		
	}

	@Override
	public List<PointCustom> searchUsersInPoint(PointCustom pointCustom) {
		
		return pointMapperCustom.searchUsersInPoint(pointCustom);
		
		
	}

	@Override
	public int queryPointCount() {
		// TODO Auto-generated method stub
		
		return pointMapperCustom.queryPointCount();
		
	}

	@Override
	public void deletePointById(int point_id) {
		// TODO Auto-generated method stub
		pointMapper.deleteByPrimaryKey(point_id);
	}

	@Override
	public void deletePointByMoreId(Integer[] point_id) {
		// TODO Auto-generated method stub
		
		UsersQueryVo usersQueryVo = new UsersQueryVo();
		List<Integer> point = new ArrayList<Integer>();
		for (int i=0;i<point_id.length;i++) {
			point.add(point_id[i]);
		}
		
		usersQueryVo.setUsersPoint(point);
		pointMapperCustom.deletePointByMoreId(usersQueryVo);
		
	}
	

}
