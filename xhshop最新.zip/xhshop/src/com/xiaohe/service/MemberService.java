package com.xiaohe.service;

import java.util.List;

import com.xiaohe.po.PointCustom;
import com.xiaohe.po.UserinfoCustom;
import com.xiaohe.po.UsersCustom;
import com.xiaohe.po.UsersQueryVo;

public interface MemberService {

	public void addMember(UsersQueryVo usersQueryVo);

	public void deleteMember(String ufuname);

	public void deleteMoreMember(String[] member);

	public List<UserinfoCustom> searchUsers(UsersQueryVo usersQueryVo);

	public void updateUsers(UsersQueryVo usersQueryVo);

	public void addMemberInfo(UsersQueryVo usersQueryVo);

	public int queryMember(UsersQueryVo usersQueryVo);

	public int selectUsersCount();

	public UsersQueryVo findUsers(String uname);

	public List<PointCustom> searchUsersInPoint(PointCustom pointCustom);

	public int queryPointCount();

	public void deletePointById(int point_id);

	public void deletePointByMoreId(Integer[] point_id);

}
