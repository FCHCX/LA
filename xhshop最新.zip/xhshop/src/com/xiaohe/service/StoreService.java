package com.xiaohe.service;

import java.util.List;

import com.xiaohe.po.Store;
import com.xiaohe.po.StoreShopInfoVo;

public interface StoreService {

	//添加仓库
	public void addStore(Store store)throws Exception;
	//查询
	public List<StoreShopInfoVo> searchStore()throws Exception;
	//仓库总数
	public int qureyCountStore()throws Exception;
	//删除单个仓库
	public void  DeleteStoreById(Integer stid)throws Exception;
	//批量删除
	public void deleteStoreByMoreId(Integer[] stid)throws Exception;
	//条件查找
	public List<StoreShopInfoVo> findstore(StoreShopInfoVo storeShopInfoVo)throws Exception;
	//条件查找的个数
	public int QueryFindNumber(StoreShopInfoVo storeShopInfoVo)throws Exception;
	//修改仓库值
	public void UpdateStore(Store store)throws Exception;

}
