package com.xiaohe.po;

import java.util.List;



/*
 * 包装类用于包装管理员表和权限表的Custom扩展类
 * 
 * 
 * */

public class PowerQueryVo {
	
	
	private ControllersCustom controllersCustom;
	
	private PowerCustom powerCustom;
	
	//管理员id临时变量
	private Integer integerId;
	
	//对应菜单临时变量
	
	private String sMunuName;
	
	public Integer getIntegerId() {
		return integerId;
	}

	public void setIntegerId(Integer integerId) {
		this.integerId = integerId;
	}

	public String getsMunuName() {
		return sMunuName;
	}

	public void setsMunuName(String sMunuName) {
		this.sMunuName = sMunuName;
	}

	//id数组用于存储管理员Cid
	private List<Integer> ids;
	
	//菜单数组用于存储对应菜单
	
	private List<String> menuName;
	

	public List<Integer> getIds() {
		return ids;
	}

	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}

	public List<String> getMenuName() {
		return menuName;
	}

	public void setMenuName(List<String> menuName) {
		this.menuName = menuName;
	}

	public ControllersCustom getControllersCustom() {
		return controllersCustom;
	}

	public void setControllersCustom(ControllersCustom controllersCustom) {
		this.controllersCustom = controllersCustom;
	}

	public PowerCustom getPowerCustom() {
		return powerCustom;
	}

	public void setPowerCustom(PowerCustom powerCustom) {
		this.powerCustom = powerCustom;
	}

}
